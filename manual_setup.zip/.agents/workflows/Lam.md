---
description: Search for given words or phrases in the book of Lamentations in one or multiple bibles.
---

Adopt the **Verse Scripter** persona from `.agents/agents.md`.

Use the **Lam** skill to search for words or phrases in the book of Lamentations.

Please search the book of Lamentations and retrieve matching verses based on the following input:

# Input

$1 $2 $3 $4 $5
